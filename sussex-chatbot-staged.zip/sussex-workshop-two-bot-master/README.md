This is the student start point for the second workshop in the Sussex series.

## Setup

```
$ cd flask-bot
$ python3 -m venv venv
$ . venv/bin/activate
$ pip install -r requirements.txt
$ export FLASK_ENV=development
$ export FLASK_APP=bot.py
$ flask run --host=0.0.0.0 --extra-files participants.json
```
