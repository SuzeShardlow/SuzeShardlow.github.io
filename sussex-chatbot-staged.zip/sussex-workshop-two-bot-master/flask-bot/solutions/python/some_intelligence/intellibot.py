from flask import Flask

from flask import render_template
from flask import request
from flask import session

import json
import string

# Load temporary participant data from JSON file.
with open("participants.json", "r") as f:
    participant_data = json.load(f)

# Initialize Flask.
app = Flask(__name__)

# Set a secret key for session management reasons.
# Flask internals...
app.secret_key = "factnetwork"

# Returns true if the list of words in "keywords" 
# contains any of the words in the list "message_words".
# Used to determine user intent.
def contains_keywords(keywords, message_words):
    matched_words = set(keywords) & set(message_words)
    return len(matched_words) > 0

# Determine how to respond to a message from the user.
def interpret_message(message):
    # The name the bot will reply with.
    bot_name = "Bot"

    # Check that the user actually typed something...
    if (len(message) == 0):
        return "{}: Please ask a question.".format(bot_name)
    
    # Remove punctuation from message to make it easier to match.
    message_no_punctuation = message.translate(str.maketrans("", "", string.punctuation))

    # Make the message all lower case for comparison purposes.
    message_no_punctuation = message_no_punctuation.lower()

    # Make a list of words in the user's message by using the 
    # spaces in the string as a word separator.
    message_words = message_no_punctuation.split()

    # Look for hello / welcome / start of conversation keywords.
    welcome_intent_keywords = ["hello", "hi", "hey", "morning", "afternoon", "about"]

    if (contains_keywords(welcome_intent_keywords, message_words)):
        # This is a welcome / start of conversation message and will always come from
        # "Bot" rather than a specific participant.
        return "Bot: Hi, it's the archive of the Women, Risk and Aids Project here.  Ask me which participants you can speak with to explore their experiences."

    # Look for goodbye / end of conversation keywords.
    goodbye_intent_keywords = ["goodbye", "bye", "farewell", "cheerio"]

    if (contains_keywords(goodbye_intent_keywords, message_words)):
        # This is a goodbye / end of conversation message, end the user"s 
        # session.
        session.clear()
        return "{}: Goodbye, thanks for chatting!".format(bot_name)

    # Look for filler words that don"t really merit a reply and 
    # reply with a general platitude.
    filler_intent_keywords = ["great", "cool", "perfect", "thanks", "awesome", "nice"]

    if (contains_keywords(filler_intent_keywords, message_words)):
        return "{}: Thank you.".format(bot_name)

    # Catch all - we were not able to determine the user intent...
    return "{}: Sorry - I don't understand, please ask another question.".format(bot_name)

@app.route("/")
def home():
    # Send the front end web page.
    return render_template("index.html")

@app.route("/message", methods=["POST"])
def process_message():
    return interpret_message(request.form["message"])
