from flask import Flask

from flask import render_template
from flask import request
from flask import session

import json
import string

# Load temporary participant data from JSON file.
with open("participants.json", "r") as f:
    participant_data = json.load(f)

# Initialize Flask.
app = Flask(__name__)

# Set a secret key for session management reasons.
# Flask internals...
app.secret_key = "factnetwork"

# Determine how to respond to a message from the user.
def interpret_message(message):
    # The name the bot will reply with.
    bot_name = "Bot"

    return bot_name + ": I can't talk properly yet."
    
@app.route("/")
def home():
    # Send the front end web page.
    return render_template("index.html")

@app.route("/message", methods=["POST"])
def process_message():
    return interpret_message(request.form["message"])
from flask import Flask

from flask import render_template
from flask import request
from flask import session

import json
import string

# Load temporary participant data from JSON file.
with open("participants.json", "r") as f:
    participant_data = json.load(f)

# Initialize Flask.
app = Flask(__name__)

# Set a secret key for session management reasons.
# Flask internals...
app.secret_key = "factnetwork"

# Returns true if the list of words in "keywords" 
# contains any of the words in the list "message_words".
# Used to determine user intent.
def contains_keywords(keywords, message_words):
    matched_words = set(keywords) & set(message_words)
    return len(matched_words) > 0

# Determine how to respond to a message from the user.
def interpret_message(message):
    # The name the bot will reply with.
    bot_name = "Bot"

    # Check that the user actually typed something...
    if (len(message) == 0):
        return bot_name + ": Please ask a question."
    
    # Remove punctuation from message to make it easier to match.
    message_no_punctuation = message.translate(str.maketrans("", "", string.punctuation))

    # Make the message all lower case for comparison purposes.
    message_no_punctuation = message_no_punctuation.lower()

    # Make a list of words in the user's message by using the 
    # spaces in the string as a word separator.
    message_words = message_no_punctuation.split()

    # See if we are already talking to a participant.  We will know this
    # by checking to see if parricipant_name is set in the current session.
    if (session.get("participant_name")):
        # We are talking to a participant, so let's get which one, and update 
        # the name that the bot will reply with as well as get that participant's
        # data from the database.
        participant_name = session["participant_name"]
        bot_name = participant_name
        participant_record = None

        # Also look up the participant in the "database".
        for participant in participant_data["participants"]:
            if (participant["name"] == participant_name):
                participant_record = participant

        # See if the question matches any of the things that we 
        # can ask the currently selected participant.

        # Is this a how old are you intent?
        participant_age_intent_keywords = ["age", "old", "birthday", "teenager"]

        if (contains_keywords(participant_age_intent_keywords, message_words)):
            return bot_name + ": I am " + participant_record["age"] + " years old."

        # Is this a where are you from intent?
        participant_home_intent_keywords = ["home", "town", "city", "where", "located"]

        if (contains_keywords(participant_home_intent_keywords, message_words)):
            return bot_name + ": I am from " + participant_record["city"] + "."

        # Is this a contraception intent?
        participant_contraception_intent_keywords = ["contraception", "condom", "condoms", "sex", "pill", "pregnant", "pregnancy", "prevention"]

        if (contains_keywords(participant_contraception_intent_keywords, message_words)):
            return bot_name + ": " + participant_record["contraception"]

    # Check if a participant name was mentioned by the user.  Load the 
    # participant names from the sample data for now and make them lower case for comparison.
    all_participants = []

    for participant in participant_data["participants"]:
        all_participants.append(participant["name"].lower())

    names_mentioned = set(message_words) & set(all_participants)

    # It is a I would like to talk to <name> request if the message consists only of 
    # a participant name, or contains a participant name and at least one of the 
    # keywords for the choose participant intent.
    if (len(names_mentioned) > 0):
        # A name has been mentioned, so get the name of the participant.
        chosen_participant = next(iter(names_mentioned))

        # Look for "I'd like to talk to <name>" keywords.
        choose_participant_intent_keywords = ["speak", "talk", "with", "try", "there", "here", "available", "about", "around", "home", "in", "awake", "online", "active", "keyboard", "please", "ask"]

        # If a choose participant keyword matched or the user just typed a
        # participant name, then this is a request to talk to someone by name.
        if (contains_keywords(choose_participant_intent_keywords, message_words)) or (message_no_punctuation == chosen_participant):        
            # Store the participant name in the user's session so that we know the 
            # context of the conversation for subsequent requests.
            session["participant_name"] = chosen_participant.title()

            # Update the bot name
            bot_name = session["participant_name"]

            return bot_name + ": " + "Hello, you're talking to " + session["participant_name"] + "."

    # Look for "who can I talk to" keywords.
    who_intent_keywords = ["who", "name", "names", "person", "people", "talk", "speak"]

    if (contains_keywords(who_intent_keywords, message_words)):
        # This is a who can I talk to request, so get a list of the participants.
        participant_names = ""

        for participant in participant_data["participants"]:
            participant_names = participant_names + participant["name"] + ", "

        # Remove final ,
        participant_names = participant_names[:-2]

        return bot_name + ": " + "You can talk to any of these participants: " + participant_names

    # Look for hello / welcome / start of conversation keywords.
    welcome_intent_keywords = ["hello", "hi", "hey", "morning", "afternoon", "about"]

    if (contains_keywords(welcome_intent_keywords, message_words)):
        # This is a welcome / start of conversation message and will always come from
        # "Bot" rather than a specific participant.
        return "Bot: Hi, this is the Women's Risk and Aids Archive here.  Ask me which participants you can speak with to explore their experiences."

    # Look for goodbye / end of conversation keywords.
    goodbye_intent_keywords = ["goodbye", "bye", "farewell", "cheerio"]

    if (contains_keywords(goodbye_intent_keywords, message_words)):
        # This is a goodbye / end of conversation message, end the user"s 
        # session.
        session.clear()
        return bot_name + ": Goodbye, thanks for chatting!"

    # Look for filler words that don"t really merit a reply and 
    # reply with a general platitude.
    filler_intent_keywords = ["great", "cool", "perfect", "thanks", "awesome", "nice"]

    if (contains_keywords(filler_intent_keywords, message_words)):
        return bot_name + ": Thank you."

    # Catch all - we were not able to determine the user intent...
    return bot_name + ": Sorry - I don't understand, please ask another question."

@app.route("/")
def home():
    # Send the front end web page.
    return render_template("index.html")

@app.route("/message", methods=["POST"])
def process_message():
    return interpret_message(request.form["message"])
